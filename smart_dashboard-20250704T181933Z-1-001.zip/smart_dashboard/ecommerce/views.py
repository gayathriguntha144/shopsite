from .models import Product
from django.shortcuts import render, redirect,get_object_or_404
from .models import CartItem
from django.contrib.auth.decorators import login_required
from .models import CartItem, Order, OrderItem
from .forms import ProductForm,ProductSaleForm
from .models import ProductSale

# ✅ Product List View → Show all products in products.html
def product_list(request):
    products = Product.objects.all()
    return render(request, 'ecommerce/products.html', {'products': products})


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'ecommerce/product_detail.html', {'product': product})

@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart')

@login_required
def cart_view(request):
    cart_items = CartItem.objects.filter(user=request.user)
    return render(request, 'ecommerce/cart.html', {'cart_items': cart_items})

@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, user=request.user)
    item.delete()
    return redirect('cart')

@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'ecommerce/orders.html', {'orders': orders})

@login_required
def checkout(request):
    cart_items = CartItem.objects.filter(user=request.user)
    if request.method == 'POST':
        order = Order.objects.create(user=request.user)
        for item in cart_items:
            OrderItem.objects.create(order=order, product=item.product, quantity=item.quantity)
        cart_items.delete()
        return redirect('order-list')  # After placing order, go to orders page
    return render(request, 'ecommerce/checkout.html', {'cart_items': cart_items})

@login_required
def home(request):
    sales = ProductSale.objects.all()
    labels = [sale.product.name for sale in sales]
    data = [sale.quantity for sale in sales]

    form = ProductSaleForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        return redirect('ecommerce-home')  # Adjust URL name if needed

    return render(request, 'ecommerce/home.html', {
        'form': form,
        'labels': labels,
        'data': data,
    })

@login_required
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ecommerce-home')
    else:
        form = ProductForm()
    return render(request, 'ecommerce/add_product.html', {'form': form})

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('product-list')  # Redirect to product list page
    else:
        form = ProductForm()
    return render(request, 'ecommerce/add_product.html', {'form': form})


def product_list(request):
    products = Product.objects.all()
    return render(request, 'ecommerce/products.html', {'products': products})

from .models import CartItem

@login_required
def add_to_cart(request, product_id):
    product = Product.objects.get(id=product_id)
    cart_item, created = CartItem.objects.get_or_create(
        user=request.user,
        product=product,
    )
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart')
