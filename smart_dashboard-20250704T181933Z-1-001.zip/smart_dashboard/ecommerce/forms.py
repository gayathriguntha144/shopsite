from django import forms
from .models import ProductSale, Product

# Form to Add a Sale (used on the main dashboard page)
class ProductSaleForm(forms.ModelForm):
    class Meta:
        model = ProductSale
        fields = ['product', 'quantity']

# Form to Add a Product (used in the add-product page)
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price']
